# To run the app, run the following command:

```
python apriori.py

```